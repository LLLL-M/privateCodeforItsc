#ifndef _MESSAGE_H_
#define GPIO_Pin_H  ((uint16_t)0xFF00)                                                //����GPIO��8λ
#define GPIO_Pin_L  ((uint16_t)0x00FF)                                                //����GPIO��8λ
#define   PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)                 //�궨��Printf  ����
extern void GPIOAL_IN_Int(void);                                                           //GPIOA��8λ����ʹ��
extern void GPIOAL_Out_Int(void);                                                        //GPIOA��8λ���ʹ��
extern void GPIO_Configuration(void);                                                   //GPIOʹ�ܣ�����Ƭѡ��
extern void GPIO_Port_Int(void);                                                            //GPIO���ݳ�ʼ��  
extern void Usart_Configruation(void);                                                     //usart1��ʼʹ��  
extern void NVIC_Configuration(void);                                                     //�ն�ʹ��
extern void Timer2_Configuration(void);                                                   //Time2��ʼʹ��    
extern void Timer3_Configuration(void);                                                   //Time3��ʼʹ��   
extern void GPIOAL_IN_Int(void);
extern void  HMI_CAN_Init(void);
extern void RCC_Configuration(void);
//extern volatile CanTxMsg TxMessage;
#endif
